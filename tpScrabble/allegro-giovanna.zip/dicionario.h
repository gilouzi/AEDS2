#ifndef DICIONARIO_H
#define DICIONARIO_H

#define ALPHABET_SIZE 26

typedef struct trie_node {
  char letra;
  int fimPalavra;
  struct trie_node *filho; // com ALPHABET_SIZE posições
} trie_node_t;

typedef struct trie {
  struct trie_node *firstLevel; // com ALPHABET_SIZE posições
} trie_t;

#endif